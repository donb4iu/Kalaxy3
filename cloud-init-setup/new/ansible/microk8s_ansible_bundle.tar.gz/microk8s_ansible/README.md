# Mixed-arch 8-node MicroK8s cluster with Ansible

This project builds a mixed ARM64/AMD64 MicroK8s cluster with:

- DNS
- RBAC
- Kubernetes Dashboard exposed through MetalLB
- MetalLB
- Ingress
- Observability with Prometheus, Grafana, Loki, and Tempo
- NVIDIA GPU support on the AMD64 GPU nodes
- NFS CSI dynamic provisioning backed by `192.168.2.7`
- MinIO Operator + Tenant using multi-node storage
- Architecture-aware namespaces for `arm64` and `amd64`

## What this replaces from the notes

- Keeps: `dns`, `dashboard`, `ingress`, `metallb`, dashboard admin user, dashboard LoadBalancer, long-lived dashboard token idea, GPU on amd64, architecture-aware scheduling, and the `192.168.2.20-192.168.2.49` MetalLB pool.
- Replaces: the deprecated `microk8s enable prometheus` flow with a Helm-based observability stack.
- Replaces: the default/local storage path for observability with NFS-backed PVCs.
- Replaces: the single-server/single-volume MinIO example with a distributed tenant.
- Avoids: using hostpath/local storage as the default storage class.

## Assumptions

- All nodes run Ubuntu with snap support.
- SSH works from the Ansible control host.
- NFS server `192.168.2.7` exports `/srv/nfs/microk8s`.
- The five ARM nodes and three AMD nodes are already provisioned and reachable.
- NVIDIA drivers already work on the GPU AMD64 nodes (`nvidia-smi` succeeds).
- The secondary HDD on each MinIO node is mounted at `/mnt/hdisk` before tenant deployment.

## Usage

1. Edit `inventory/hosts.yml`.
2. Edit `group_vars/all.yml`.
3. Run:

```bash
ansible-playbook -i inventory/hosts.yml site.yml
```

## Important notes

- The first control-plane node in `microk8s_primary` is used to initialize the cluster.
- By default, all cluster storage claims should target `nfs-csi` unless you explicitly choose another class.
- MinIO tenant PVCs use `openebs-jiva-csi-default` by default because the MicroK8s/OpenEBS docs describe that class for multi-node volumes. If you want MinIO backed by a different replicated block class, update `minio_storage_class`.
